meshes = {
  {
    vertexes = {{0,0}, {500,0}, {500,500}, {0,500}},
    colors = {0xffffffff, 0xffff00ff, 0xff00ffff, 0x00ff0000},
    segments = {{0,1,2,3,0}}
  }
}
